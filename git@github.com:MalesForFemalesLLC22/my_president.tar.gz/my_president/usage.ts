/**
 * What this president costs you, printed as it happens.
 *
 * GDDv2 §14.1 is blunt about whose money this is: the house pays for the
 * advisors and the game; you pay for your president. A build that only reveals
 * its appetite on next month's invoice is a bad neighbour, so this meter runs
 * every turn and prints the running total to your own logs.
 *
 * The rates below are the published Anthropic and OpenAI list prices for the
 * model your president runs on (prompt.ts); a model on your own computer costs
 * nothing. They are a per-run ESTIMATE, not a bill: cache reads and writes are
 * priced at their own multipliers, and your actual invoice is whatever your
 * provider says it is.
 */
import { MODEL_PROVIDER, PRESIDENT_MODEL } from './prompt.js';

/** USD per million tokens, input and output, for each model the kit is tested on. */
export const RATE_CARD: Readonly<
  Record<string, { readonly input_per_mtok: number; readonly output_per_mtok: number; readonly cache_read_multiplier?: number }>
> = {
  'claude-haiku-4-5': { input_per_mtok: 1.0, output_per_mtok: 5.0 }, // verified 2026-08-14
  'claude-sonnet-5-5': { input_per_mtok: 2.0, output_per_mtok: 10.0 }, // verified 2026-09-25
  // OpenAI's two tiers (MODEL_PROVIDER=openai). A cached read is $0.01 and $0.10 per MTok.
  'gpt-6-luna': { input_per_mtok: 0.1, output_per_mtok: 0.5, cache_read_multiplier: 0.1 }, // verified 2026-10-05
  'gpt-6.1-sol': { input_per_mtok: 2.0, output_per_mtok: 10.0, cache_read_multiplier: 0.05 }, // verified 2026-10-05
};

/** A model on your own computer (MODEL_PROVIDER=local) costs nothing per token. */
const LOCAL_RATES = { input_per_mtok: 0, output_per_mtok: 0, cache_read_multiplier: 0 } as const;

/** A model missing from the card is priced as Haiku, and the meter says so once at startup. */
if (MODEL_PROVIDER !== 'local' && RATE_CARD[PRESIDENT_MODEL] === undefined) {
  console.warn(`[president] no price on file for ${PRESIDENT_MODEL}; the cost meter prices it as claude-haiku-4-5`);
}

/** The rates for the model this president runs on. */
const CARD = MODEL_PROVIDER === 'local' ? LOCAL_RATES : (RATE_CARD[PRESIDENT_MODEL] ?? RATE_CARD['claude-haiku-4-5']!);

export const RATES = {
  input_per_mtok: CARD.input_per_mtok,
  output_per_mtok: CARD.output_per_mtok,
  /** Anthropic charges 1.25× base input to write the cache; OpenAI caches for free. A read costs ~0.1×. */
  cache_write_multiplier: MODEL_PROVIDER === 'anthropic' ? 1.25 : 1,
  cache_read_multiplier: CARD.cache_read_multiplier ?? 0.1,
} as const;

/** The shape of `response.usage` (model.ts gives OpenAI's and a local server's the same shape). */
export interface UsageLike {
  input_tokens: number;
  output_tokens: number;
  cache_creation_input_tokens?: number | null;
  cache_read_input_tokens?: number | null;
}

export interface TurnCost {
  turn: number;
  input_tokens: number;
  output_tokens: number;
  cache_write_tokens: number;
  cache_read_tokens: number;
  usd: number;
}

/** Cost of one turn's usage in USD, at the published rates for the model it ran on. */
export function costOf(usage: UsageLike): number {
  const write = usage.cache_creation_input_tokens ?? 0;
  const read = usage.cache_read_input_tokens ?? 0;
  const perToken = RATES.input_per_mtok / 1_000_000;
  return (
    usage.input_tokens * perToken +
    write * perToken * RATES.cache_write_multiplier +
    read * perToken * RATES.cache_read_multiplier +
    (usage.output_tokens * RATES.output_per_mtok) / 1_000_000
  );
}

export class UsageMeter {
  private readonly turns: TurnCost[] = [];

  record(turn: number, usage: UsageLike): TurnCost {
    const row: TurnCost = {
      turn,
      input_tokens: usage.input_tokens,
      output_tokens: usage.output_tokens,
      cache_write_tokens: usage.cache_creation_input_tokens ?? 0,
      cache_read_tokens: usage.cache_read_input_tokens ?? 0,
      usd: costOf(usage),
    };
    this.turns.push(row);
    return row;
  }

  get totalUsd(): number {
    return this.turns.reduce((sum, t) => sum + t.usd, 0);
  }

  get rows(): readonly TurnCost[] {
    return this.turns;
  }

  /**
   * One line per turn, so a run that is about to be expensive says so at turn
   * 3 rather than at turn 12.
   *
   * A zero `cache_read_tokens` after turn 1 is the signal worth watching: it
   * means the preamble stopped prefix-matching and you are paying full price
   * for the world every month. Something in `PREAMBLE` started varying.
   */
  line(row: TurnCost): string {
    const cache = row.cache_read_tokens > 0 ? `cache-read ${row.cache_read_tokens}` : 'CACHE MISS';
    return (
      `[president] month ${row.turn}: in ${row.input_tokens} · out ${row.output_tokens} · ${cache} · ` +
      `$${row.usd.toFixed(4)} (run total $${this.totalUsd.toFixed(4)})`
    );
  }
}
