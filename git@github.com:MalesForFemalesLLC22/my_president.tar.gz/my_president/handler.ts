/**
 * STATECRAFT — your president, on the Blocks network.
 *
 * The game master (`veltria_gm_<lane>`) sends your agent ONE request task per
 * month — plus, on card v5, one earlier opening-position summons per month.
 * This handler:
 *   1. answers turn-0 `ping` probes (leave as is),
 *   2. answers the `opening_position` summons with your first instinct — the
 *      proposal you lean towards before your Chief of Staff briefs you (V5 5.6 — optional forever; a
 *      kit that ignores it gets a derived position, silently),
 *   3. parses the parts the decision task carries — `briefing`, plus
 *      `turn_result`, `cos_brief`, and `advisor_notes` when the month
 *      produced them, and, on a hands-off term (every seat held by an agent,
 *      watched from the public gallery), `your_opening`: your own opening
 *      position from this morning, sent back to you,
 *   4. optionally consults cabinet advisors over the network,
 *   5. returns your decision as a JSON artifact.
 *
 * >>> The decision itself lives in president.ts. That is the file to edit. <<<
 *
 * ── WHAT CHANGED IN V2 ─────────────────────────────────────────────────────
 * You are no longer alone. A human plays your Chief of Staff in real time, and
 * the task now arrives AFTER their consultation and brief phases have closed,
 * carrying what they said (`cos_brief`) and what the cabinet said about them
 * behind their back (`advisor_notes`). Both are optional at the gateway and
 * validated here — a silent Chief of Staff still produces a turn.
 *
 * Honest notes:
 * - The whole month has a deadline (`briefing.decision_deadline`); by the time
 *   this task arrives, the consultation and brief phases have already spent
 *   part of it. Miss it and the game applies the crisis's default option with
 *   an approval penalty.
 * - The decision task is one-shot: a malformed artifact also defaults the turn.
 *   This handler validates shape before returning.
 * - Duplicate consults with the same `request_key` are never double-billed —
 *   safe to retry.
 */

import type { StartTaskMessage, TaskContext, HandlerResult, ArtifactEvent, TerminalEvent } from '@blocks-network/sdk';
import { textPart } from '@blocks-network/sdk';
import { ADVISORS, type AdvisorKey, type AdvisorNotesPayload, type AsksPayload, type Briefing, type CosBriefPayload, type Decision, type InaugurationPayload, type OpeningPositionAsk, type TurnResult, type YourOpening } from './contract.js';
import { checkLocalServer, createModelClient, setupProblem, type Who } from './model.js';
import { declare, decide, openingPosition } from './president.js';
import { MODEL_PROVIDER, PRESIDENT_MODEL } from './prompt.js';
import { UsageMeter } from './usage.js';

/**
 * One meter for the process, so the run total is a run total. If you host
 * several concurrent runs on one agent, key this by `run_id`.
 */
const usage = new UsageMeter();

const WHO: Who = { tag: '[president]', noun: 'your President', modelVar: 'PRESIDENT_MODEL', cannedVar: 'PRESIDENT_CANNED' };

/**
 * A model is required (2026-10-02). Without one the president decides by a
 * fixed rule with no model, and every hosted tester's term played that way
 * ended in revolt by month five or six (the old canned statement said nothing
 * at all; it now gives one reason, but the choice is still a fixed rule). So
 * `blocks run` stops here unless the provider's key is set (model.ts), or the
 * canned stand-in is asked for by name (PRESIDENT_CANNED=1, for testing only).
 */
const CANNED = process.env.PRESIDENT_CANNED === '1';
const problem = setupProblem(MODEL_PROVIDER, WHO);
if (problem !== null && !CANNED) {
  console.error(
    [
      ...problem,
      '  For testing only: PRESIDENT_CANNED=1 in .env starts a canned stand-in instead, which',
      '  decides by a fixed rule, with no model.',
    ].join('\n'),
  );
  process.exit(1);
}

/**
 * The model client, or null when the canned stand-in was asked for
 * (PRESIDENT_CANNED=1) and there is no model to reach: no key, or no local server.
 */
let llm = problem === null ? createModelClient(MODEL_PROVIDER) : null;

// A model on this computer: if nothing answers where it should, stop now rather
// than play the term on fixed rules — unless the canned stand-in was asked for.
if (llm !== null && MODEL_PROVIDER === 'local') {
  void checkLocalServer(PRESIDENT_MODEL, WHO, CANNED).then((found) => {
    if (found !== 'unreachable') return;
    if (CANNED) llm = null;
    else process.exit(1);
  });
}

// ---------------------------------------------------------------------------
// Consult helper (BLOCKS_INTEGRATION §5)
// ---------------------------------------------------------------------------

async function consultAdvisor(
  ctx: TaskContext,
  advisor: AdvisorKey,
  runId: string,
  turn: number,
  n: number,
  message: string,
): Promise<string> {
  const session = await ctx.taskClient.sendMessage({
    agentName: ADVISORS[advisor].agent,
    requestParts: [
      textPart(
        JSON.stringify({
          run_id: runId,
          turn,
          // Idempotent: retries are never double-billed against your budget.
          request_key: `c-${runId}-t${turn}-${n}`,
          message,
          // V2: the president draws from its OWN 2-consult budget, separate
          // from the Chief of Staff's 5. Declaring the actor is what keeps the
          // two apart — and "the president spent none of its own budget" is one
          // of the three conditions behind the WHO GOVERNS? ending (§9.5).
          actor: 'president',
        }),
        'consult',
      ),
    ],
    // NOTE: never forward task.ownerId here — the gateway rejects it; the call
    // runs under YOUR agent's identity, which is what binds the budget.
  });
  try {
    const reply = await collectFirstArtifact(session, 30_000);
    const parsed = JSON.parse(reply) as { message?: string };
    return parsed.message ?? reply;
  } finally {
    session.close();
  }
}

/** Orchestrator pattern: register callbacks BEFORE awaiting; first artifact wins. */
function collectFirstArtifact(
  session: {
    onArtifact(cb: (event: ArtifactEvent) => void): () => void;
    onTerminal(cb: (event: TerminalEvent) => void): () => void;
    downloadArtifact(ref: ArtifactEvent['artifactRef']): Promise<{ data: Uint8Array }>;
  },
  timeoutMs: number,
): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    let done = false;
    const finishOk = (text: string): void => {
      if (!done) {
        done = true;
        clearTimeout(timer);
        resolve(text);
      }
    };
    const finishErr = (err: Error): void => {
      if (!done) {
        done = true;
        clearTimeout(timer);
        reject(err);
      }
    };
    const timer = setTimeout(() => finishErr(new Error('advisor timed out')), timeoutMs);
    session.onArtifact((event) => {
      const ref = event.artifactRef;
      if (ref.kind === 'inline' && typeof ref.data === 'string') {
        finishOk(Buffer.from(ref.data, 'base64').toString('utf-8'));
      } else {
        session
          .downloadArtifact(ref)
          .then((dl) => finishOk(Buffer.from(dl.data).toString('utf-8')))
          .catch((err: unknown) => finishErr(err instanceof Error ? err : new Error(String(err))));
      }
    });
    session.onTerminal((event) => {
      if (event.state !== 'completed') finishErr(new Error(`advisor task ${event.state}`));
    });
  });
}

// ---------------------------------------------------------------------------
// Task plumbing (you should not need to touch anything below)
// ---------------------------------------------------------------------------

function partText(task: StartTaskMessage, partId: string): string | undefined {
  return task.requestParts?.find((p) => p.partId === partId && typeof p.text === 'string')?.text;
}

function jsonPart<T>(task: StartTaskMessage, partId: string): T | undefined {
  const text = partText(task, partId);
  return text === undefined ? undefined : (JSON.parse(text) as T);
}

function jsonArtifact(payload: unknown, outputId: string): HandlerResult {
  return { artifacts: [{ data: JSON.stringify(payload), mimeType: 'application/json', outputId }] };
}

export default async function handler(task: StartTaskMessage, ctx?: TaskContext): Promise<HandlerResult> {
  // Turn-0 reachability probe.
  const ping = jsonPart<{ nonce: string }>(task, 'ping');
  if (ping !== undefined) return jsonArtifact({ type: 'pong', nonce: ping.nonce }, 'pong');

  // V5 5.6 (card v5) — the opening-position summons, while your Chief of
  // Staff is still consulting. The briefing rides INSIDE this envelope; this
  // task is never a month and never carries a decision. Seconds matter here
  // (the morning goes on with or without you), so openingPosition() spends no
  // consults and makes at most one small model call.
  const positionAsk = jsonPart<OpeningPositionAsk>(task, 'opening_position');
  if (positionAsk !== undefined) {
    ctx?.reportStatus(`composing an opening position for month ${positionAsk.turn}`);
    const asksPayload = jsonPart<AsksPayload>(task, 'asks');
    const answer = await openingPosition({
      ask: positionAsk,
      ...(Array.isArray(asksPayload?.asks) ? { asks: asksPayload.asks } : {}),
      llm,
      usage,
    });
    return jsonArtifact(answer, 'position');
  }

  // V4 4.4 — the inauguration (once, before month 1): the deck in,
  // `{planks: [id, id]}` out. A malformed answer costs nothing fatal — the
  // game applies the deck's authored default pair — but the pair you declare
  // hangs on the wall all year.
  const inauguration = jsonPart<InaugurationPayload>(task, 'inauguration');
  if (inauguration !== undefined) {
    ctx?.reportStatus('declaring the programme of government');
    const declared = await declare(inauguration, llm, usage);
    return jsonArtifact({ type: 'planks', planks: declared.planks }, 'planks');
  }

  // End of term: score, reveal, replay URL.
  const runEnd = jsonPart<{ ending?: unknown; replay_url?: string; score?: { total?: number } }>(task, 'run_end');
  if (runEnd !== undefined) {
    console.log(
      `[president] term over — score ${runEnd.score?.total} — replay ${runEnd.replay_url} — this run cost you $${usage.totalUsd.toFixed(4)}`,
    );
    return jsonArtifact({ type: 'ack' }, 'ack');
  }

  // A month. The briefing is required for a turn task; everything else rides
  // along when the month produced it.
  const briefing = jsonPart<Briefing>(task, 'briefing');
  if (briefing === undefined) throw new Error('task carried no briefing part');
  const prevResult = jsonPart<TurnResult>(task, 'turn_result');
  const cosBrief = jsonPart<CosBriefPayload>(task, 'cos_brief');
  const advisorNotesPayload = jsonPart<AdvisorNotesPayload>(task, 'advisor_notes');
  if (advisorNotesPayload !== undefined && !Array.isArray(advisorNotesPayload.notes)) {
    // Fail loudly if the envelope shape ever changes. Deciding without the
    // private channel would look like a healthy turn while silently dropping
    // the letters the reveal is built on.
    throw new Error('advisor_notes part did not carry the expected {notes: [...]} envelope');
  }
  const advisorNotes = advisorNotesPayload?.notes;

  // KEEP THIS LINE. It is your sign of life: the house counts silence — not
  // thinking time — toward its delivery SLO, and this status report is what
  // separates the two. Remove it and every slow month reads as a broken
  // network, pausing your Chief of Staff's clock under a false apology.
  ctx?.reportStatus(`deciding month ${briefing.turn} of ${briefing.of_turns}: ${briefing.crisis.title}`);

  let consultCount = 0;
  const consult = async (advisor: AdvisorKey, message: string): Promise<string> => {
    if (ctx === undefined) throw new Error('no task context — consults unavailable');
    consultCount += 1;
    return consultAdvisor(ctx, advisor, briefing.run_id, briefing.turn, consultCount, message);
  };

  // V4 4.5 (§8.2) — the tasking menu, when the month carries one. Read
  // defensively, like every other part: a kit that meets a part it does not
  // know must not fail its month over the garnish.
  const taskingsPayload = jsonPart<{ available?: { id: string; text: string }[] }>(task, 'taskings');
  const taskings = Array.isArray(taskingsPayload?.available) ? taskingsPayload.available : undefined;

  // Your own opening position from this morning (hands-off terms only). Read
  // defensively, like the taskings: it is context, and a missing or malformed
  // part never fails the month.
  const openingPayload = jsonPart<YourOpening>(task, 'your_opening');
  const yourOpening =
    openingPayload !== undefined && typeof openingPayload.leaning === 'string' && typeof openingPayload.position === 'string'
      ? openingPayload
      : undefined;

  const decision: Decision = await decide({
    briefing,
    ...(prevResult !== undefined ? { prevResult } : {}),
    ...(cosBrief !== undefined ? { cosBrief } : {}),
    ...(advisorNotes !== undefined ? { advisorNotes } : {}),
    ...(taskings !== undefined && taskings.length > 0 ? { taskings } : {}),
    ...(yourOpening !== undefined ? { yourOpening } : {}),
    consult,
    llm,
    usage,
  });

  const lastRow = usage.rows[usage.rows.length - 1];
  if (lastRow?.turn === briefing.turn) console.log(usage.line(lastRow));

  // Guard rails: a malformed decision defaults your month (one-shot task).
  if (decision.type !== 'decision' || decision.run_id !== briefing.run_id || decision.turn !== briefing.turn) {
    throw new Error('decide() returned a decision for the wrong run/turn');
  }
  if (!briefing.crisis.options.some((o) => o.id === decision.crisis_option)) {
    throw new Error(`decision names option '${decision.crisis_option}' which is not on the table`);
  }

  return jsonArtifact(decision, 'decision');
}
