// sync-org.mjs — puts your Blocks organization's current name in agent-card.json.
//
//   npm run sync-org                  set the card's organization from `blocks whoami`
//   npm run publish:agent             the same, then publish, listed in the catalog
//   npm run publish:agent -- --private   the same, then publish as private, out of the catalog
//
// Blocks shows agent-card.json's `identity.provider.organization` as your
// organization's name, so a card carrying any other name can rename your
// organization (a tester's was renamed after each President she built). This
// script copies the name your organization already has into the card before
// anything is registered or published. It never passes `--org-name`. When
// `blocks whoami` cannot be read it stops, and nothing is published.
//
// Plain Node, no dependencies. The same file ships in every STATECRAFT kit.

import { spawnSync } from 'node:child_process';
import { readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

/**
 * Pure: the card's text with `identity.provider.organization` set to the
 * organization's current name. `whoamiStdout` is `blocks whoami --json`'s
 * output. Returns the new text (unchanged when nothing needs doing) and what
 * happened: 'set', 'already', 'unnamed' (the organization has no name yet —
 * its first publish, where the CLI asks for one) or 'failed' (with a reason;
 * nothing may be published then).
 */
export function syncCardText(cardText, whoamiStdout) {
  let who;
  try {
    who = JSON.parse(whoamiStdout);
  } catch {
    return { status: 'failed', text: cardText, reason: '`blocks whoami --json` did not print your account details' };
  }
  if (who === null || typeof who !== 'object') {
    return { status: 'failed', text: cardText, reason: '`blocks whoami --json` did not print your account details' };
  }
  if (who.expired === true) {
    return { status: 'failed', text: cardText, reason: 'your Blocks login has expired' };
  }
  const name = typeof who.org_name === 'string' ? who.org_name.trim() : '';
  if (name === '') return { status: 'unnamed', text: cardText };

  let card;
  try {
    card = JSON.parse(cardText);
  } catch {
    return { status: 'failed', text: cardText, reason: 'agent-card.json is not valid JSON' };
  }
  if (card.identity === undefined || card.identity === null || typeof card.identity !== 'object') {
    return { status: 'failed', text: cardText, reason: 'agent-card.json has no identity section' };
  }
  card.identity.provider = card.identity.provider ?? {};
  if (card.identity.provider.organization === name) return { status: 'already', text: cardText, name };
  card.identity.provider.organization = name;
  // Keep the file's own indentation and trailing newline.
  const indent = /^[ \t]+(?=")/m.exec(cardText)?.[0] ?? '  ';
  const text = JSON.stringify(card, null, indent) + (cardText.endsWith('\n') ? '\n' : '');
  return { status: 'set', text, name };
}

function stop(cause, fix) {
  console.error(`[sync-org] ${cause} Nothing was changed or published.${fix === undefined ? '' : ` ${fix}`}`);
  process.exit(1);
}

function main(argv) {
  const publish = argv.includes('--publish');
  const listing = argv.includes('--private') ? 'private' : 'public';

  // BLOCKS_PROFILE is read by the CLI itself; nothing here prints a key.
  const whoami = spawnSync('blocks', ['whoami', '--json'], { encoding: 'utf8' });
  if (whoami.error !== undefined || whoami.status !== 0) {
    stop(
      '`blocks whoami` failed, so your organization\'s name could not be read.',
      'Log in with `blocks login --write-env` and check that `blocks whoami` works. Then run this again.',
    );
  }
  const cardText = readFileSync('agent-card.json', 'utf8');
  const result = syncCardText(cardText, whoami.stdout);
  if (result.status === 'failed') {
    if (result.reason === 'your Blocks login has expired') {
      stop('Your Blocks login has expired.', 'Run `blocks login --write-env`, then run this again.');
    }
    stop(`Could not set the card's organization: ${result.reason}.`);
  }
  if (result.status === 'set') {
    writeFileSync('agent-card.json', result.text);
    console.log(`[sync-org] Set the organization in agent-card.json to "${result.name}", your Blocks organization's current name.`);
  } else if (result.status === 'already') {
    console.log(`[sync-org] The organization in agent-card.json is already "${result.name}", your Blocks organization's current name.`);
  } else {
    console.log(
      '[sync-org] Your Blocks organization has no name yet, so agent-card.json was left as it is. On your organization\'s first publish the CLI asks you for a name, and Blocks.ai shows that name in public beside your agents.',
    );
  }
  if (!publish) return;

  const published = spawnSync('blocks', ['publish', '--billing-mode', 'free', '--listing', listing, '--accept-terms'], {
    stdio: 'inherit',
  });
  process.exit(published.status ?? 1);
}

// Run as a script (not when a test imports it); realpath, so a symlinked folder still matches.
const self = fileURLToPath(import.meta.url);
if (process.argv[1] !== undefined && realpathSync(process.argv[1]) === realpathSync(self)) {
  main(process.argv.slice(2));
}
