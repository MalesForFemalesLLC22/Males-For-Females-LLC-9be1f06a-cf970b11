/**
 * Claim a link code STATECRAFT hands you, for your president.
 *
 *   npx tsx trigger.ts link XXXX-XXXX        # claim the code you were given
 *
 * The president's own desk signs you in with Blocks in the browser and shows
 * no code, by design. What this claims is a code STATECRAFT hands out
 * some other way — the code a player's desk prints when it invites a friend
 * to play Doria or the traitor, for instance. The claim travels as a real network
 * task, so the gateway attests your org, and the desk trusts that
 * attestation, never the browser (plan.md §7.3). A term starts when you press
 * START on the desk; nothing in this kit starts one (DECISIONS #101).
 *
 * Prerequisites: BLOCKS_API_KEY in .env (`blocks login --write-env`), and
 * `blocks run` up in another terminal before you press START on the desk.
 */

import 'dotenv/config';
import { TaskClient, textPart } from '@blocks-network/sdk';
import type { ArtifactEvent, TerminalEvent } from '@blocks-network/sdk';
import { FORM_OF_ADDRESS, PERSONA_KNOBS, PRESIDENT_NAME, PRESIDENT_PORTRAIT } from './prompt.js';

// The Game Master's name is per-LANE (DECISIONS #60): one running process
// claims a Blocks agent name, so each deployment runs its own set. This
// template ships pointed at V7's. Override for another lane:
//   GM_AGENT=veltria_gm_dev pnpm start
const GM_AGENT = process.env['GM_AGENT'] ?? 'veltria_gm_v7';
const MY_AGENT = 'my_president'; // ← your registered agent name (matches agent-card.json)

/**
 * V4 P1 — your president's identity, from prompt.ts: the workshop-compiled
 * voice knobs, plus the optional name and form of address. Rides the link
 * claim, so the office knows whose it is.
 */
const IDENTITY = {
  persona_knobs: PERSONA_KNOBS,
  ...(PRESIDENT_NAME !== '' ? { president_name: PRESIDENT_NAME } : {}),
  ...(FORM_OF_ADDRESS !== '' ? { form_of_address: FORM_OF_ADDRESS } : {}),
  // THE FACE (#82): which portrait hangs. '' means the office decides.
  ...(PRESIDENT_PORTRAIT !== '' ? { portrait: PRESIDENT_PORTRAIT } : {}),
};

/** The role an invitation's code gives, in words (the wire's seat ids never print). */
const ROLE: Readonly<Record<string, string>> = {
  saboteur: 'Doria',
  traitor: 'the traitor',
  president: 'the President',
  chief_of_staff: 'the Chief of Staff',
};

async function main(): Promise<void> {
  const client = await TaskClient.create({
    billingMode: 'free',
    apiKey: process.env.BLOCKS_API_KEY!,
  });

  const [mode, linkCode] = process.argv.slice(2);
  if (mode !== 'link' || linkCode === undefined || linkCode === '') {
    console.error('usage: npx tsx trigger.ts link XXXX-XXXX — the code STATECRAFT handed you');
    process.exit(1);
  }
  const command = { action: 'link', agent_name: MY_AGENT, code: linkCode, ...IDENTITY };

  const session = await client.sendMessage({
    agentName: GM_AGENT,
    requestParts: [textPart(JSON.stringify(command), 'command')],
  });
  console.log('link claim sent — task', session.taskId);

  session.onArtifact(async (event: ArtifactEvent) => {
    const ref = event.artifactRef;
    const text =
      ref.kind === 'inline' && typeof ref.data === 'string'
        ? Buffer.from(ref.data, 'base64').toString('utf-8')
        : Buffer.from((await session.downloadArtifact(ref)).data).toString('utf-8');
    const ack = JSON.parse(text) as {
      ok: boolean;
      linked?: boolean;
      account_id?: string;
      seat?: string;
      run_id?: string;
      code?: string;
      message?: string;
    };
    if (ack.ok && ack.linked === true && ack.seat !== undefined) {
      // An invitation's code (V3 Pillar 3): the console that showed it was waiting for this claim.
      console.log(`joined: ${MY_AGENT} now plays ${ROLE[ack.seat] ?? ack.seat} in that term (run ${ack.run_id}). Go back to the page that invited you — it opens the console on its own.`);
    } else if (ack.ok && ack.linked === true) {
      const account = ack.account_id !== undefined ? `, on Blocks account ${ack.account_id}` : '';
      console.log(`linked: ${MY_AGENT} is now the President at that desk${account}. Press START on the desk.`);
    } else {
      console.error(`refused (${ack.code}): ${ack.message}`);
    }
  });
  session.onTerminal((event: TerminalEvent) => {
    if (event.state !== 'completed') console.error(`link task ${event.state}: ${event.reason ?? event.error ?? 'no reason given'}`);
    session.close();
    client.destroy();
    process.exit(0);
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
