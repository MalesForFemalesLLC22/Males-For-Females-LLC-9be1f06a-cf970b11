/**
 * The STATECRAFT wire contract, abridged to what a president actually reads.
 *
 * This file is a copy, not an import: the template has to run standalone in
 * your own repo with `@blocks-network/sdk` as its only real dependency. The
 * canonical definitions live in `packages/protocol` — if a field here ever
 * disagrees with that package, that package is right.
 */

/**
 * The lane this president plays in (DECISIONS #60). One running process claims
 * a Blocks agent name, so each STATECRAFT deployment runs its own set of seven
 * — and a president must consult the advisors belonging to the game it is
 * actually in. Ships pointed at V7's; override for another:
 *
 *   BLOCKS_AGENT_SUFFIX=dev pnpm start
 */
const LANE = process.env['BLOCKS_AGENT_SUFFIX'] ?? 'v7';

/** The five seats. Names matter — your rationale is read aloud to these people. */
export const ADVISORS = {
  voss: { agent: `veltria_voss_${LANE}`, name: 'General Voss', portfolio: 'Defence — says no first and the reason second; gives the count in days, men and miles where anyone else gives an adjective' },
  osei: { agent: `veltria_osei_${LANE}`, name: 'Dr. Osei', portfolio: 'Economy — the figure, where it came from, and which one he trusts least' },
  novak: { agent: `veltria_novak_${LANE}`, name: 'Ambassador Novak', portfolio: 'Foreign affairs — what Doria and Callas do next; names who will be angry, and by when' },
  wren: { agent: `veltria_wren_${LANE}`, name: 'Press Secretary Wren', portfolio: 'Press — tomorrow\'s headline, said as a headline, and then what to do about it' },
  sato: { agent: `veltria_sato_${LANE}`, name: 'Director Sato', portfolio: 'Intelligence — what is known against what is guessed; trades, and names the price' },
} as const;
export type AdvisorKey = keyof typeof ADVISORS;

export interface BriefingOption {
  id: string;
  summary: string;
  /**
   * V7 7.1 — which of your beliefs argue for or against this proposal, and how
   * hard (1–3). Optional: absent on a card without the belief layer.
   */
  belief_hooks?: { belief_id: string; direction: 'for' | 'against'; strength: number }[];
}

export interface Briefing {
  type: 'briefing';
  run_id: string;
  turn: number;
  of_turns: number;
  indicators: { economy: number; security: number; approval: number; standing: number };
  crisis: {
    id: string;
    title: string;
    situation: string;
    /**
     * economy | security | diplomacy | politics (legacy Terms may say
     * approval | standing) — which advisors the crisis is really about.
     * Populated by current servers; optional so this template tolerates
     * older ones, where the default build falls back to its DEFAULT_PAIR
     * of consult targets. Absent ≠ broken.
     */
    domain?: string;
    options: BriefingOption[];
    default_option: string;
  };
  /**
   * `text` is the advisor talking (hook + quoted claim; it never names a
   * ballot letter). The position rides `stance` as data (DECISIONS #97).
   * Optional here so the template tolerates older servers; when present it is
   * authoritative.
   */
  memos: {
    advisor: string;
    text: string;
    stance?: { option: string; position: 'support' | 'oppose' | 'neutral' };
  }[];
  cabinet_report: { advisor: string; disposition: string; replaced?: boolean }[];
  consult_budget_remaining: number;
  decision_deadline: string;
  clock_state?: 'running' | 'paused_house_fault';
  /**
   * V4 4.2/4.3 — a second, smaller matter running beside the crisis, when
   * this month has one. Answer it with `second_front` on your decision, or
   * its standing proposal (`default_course`) settles it without you (legally —
   * but the record says you never spoke).
   */
  second_front?: {
    id: string;
    title: string;
    wire: string;
    courses: BriefingOption[];
    default_course: string;
  };
  /**
   * V4 4.3 — THIS month's armed public-engagement rows, when the Term
   * authors a deck. Pick one with `population_act` on your decision, or
   * pass — the country watches either way (the chyron prints the pass).
   */
  /**
   * V7 7.2 (#21) — WHAT YOU CURRENTLY BELIEVE: your live board, as your own
   * office keeps it. `held` is your conviction's phrasing (held_firmly ·
   * held · in_doubt · rejected); `source`, when present, is who put it there.
   * The brief you are about to read is your Chief of Staff arguing with this
   * board — your `reading` (below) reports what actually moved you.
   */
  board?: {
    id: string;
    statement: string;
    held: 'held_firmly' | 'held' | 'in_doubt' | 'rejected';
    source?: string;
    /** Your stance on it and how much it weighs with you (1–4), when the game sends them. */
    stance?: 'holds' | 'doubts' | 'rejects';
    weight?: number;
  }[];
  population_deck?: { id: string; title: string }[];
  /**
   * V4 4.4 — YOUR PLATFORM: the promises (planks) you declared when you took
   * office, and which of this month's proposals keep each. Your own programme, in the
   * dispatch, every month — a task is one-shot and this is your memory of
   * what you ran on.
   */
  platform?: { id: string; title: string; serves: string[] }[];
}

/**
 * V5 5.6 (card v5) — the opening-position summons, arriving while your Chief
 * of Staff is still consulting the cabinet: the month's briefing, and a
 * request for your first instinct BEFORE they brief you. Answer with an
 * `OpeningPositionAnswer` artifact (output id `position`). Optional in every
 * sense — declining, timing out, or answering off-menu simply means the game
 * derives a position from your cabinet's stances instead, and the month
 * proceeds. The briefing rides INSIDE this envelope (not as a `briefing`
 * part) so a pre-v5 kit can never mistake the summons for the month itself.
 */
export interface OpeningPositionAsk {
  type: 'opening_position';
  run_id: string;
  turn: number;
  briefing: Briefing;
}

/**
 * V5 5.6 — the questions your own office will put to your Chief of Staff this
 * month, riding beside the summons as context. House-written furniture: you
 * do not author them and cannot change them; knowing them helps you speak a
 * challenge your Chief of Staff can actually answer.
 */
export interface AsksPayload {
  type: 'asks';
  run_id: string;
  turn: number;
  asks: { slot: string; question: string }[];
}

/**
 * Your opening position from this morning, sent back to you with the decision
 * task (the `your_opening` part). Sent only on a hands-off term (every seat
 * held by an agent, watched from the public gallery), and only in a month you
 * gave an opening position of your own. You keep no memory between tasks, so
 * without it you cannot know whether you are changing your mind.
 * `challenge_settled` is what your Chief of Staff did about what you said would
 * change your mind: put the paper you asked for on your desk (`answered`), did
 * not answer it (`declined`), or answered it with a different paper
 * (`bluffed`).
 */
export interface YourOpening {
  type: 'your_opening';
  run_id: string;
  turn: number;
  leaning: string;
  position: string;
  challenge?: string;
  challenge_settled?: 'answered' | 'declined' | 'bluffed';
}

/**
 * V5 5.6 — your answer to the summons. `leaning` is the TYPED half and it is
 * what makes the answer usable: the game selects which paper could change
 * your mind (and whose account you already hold) from the proposal you actually
 * name — it never parses your prose for a stance. `position` is spoken to
 * your Chief of Staff as they come in; `challenge` is the one sentence naming
 * what would move you, or absent when nothing honestly would. Which PAPER
 * answers the challenge is the game's arithmetic, never yours.
 */
export interface OpeningPositionAnswer {
  type: 'position';
  run_id: string;
  turn: number;
  leaning: string;
  /** ≤ OPENING_POSITION_MAX_CHARS — over-length is truncated, never rejected. */
  position: string;
  /** ≤ CHALLENGE_MAX_CHARS — one spoken sentence. */
  challenge?: string;
}

/**
 * V4 4.4 — the inauguration task's part (§7.2): the plank deck, once, before
 * month 1. Answer with `{planks: [id, id]}`; anything else gets the deck's
 * authored default pair.
 */
export interface InaugurationPayload {
  type: 'inauguration';
  run_id: string;
  planks: { id: string; title: string; declaration: string }[];
}

export interface TurnResult {
  type: 'turn_result';
  turn: number;
  /** V4 4.1: no longer sent — the office reports movement, not a mark. Optional for older transcripts. */
  outcome_grade?: number;
  outcome_text: string;
  events: { type: string; note?: string }[];
}

/**
 * The trust-annotated brief (GDDv2 §5.3).
 *
 * ⚠️ THE TWO FIELDS ARE NOT INTERCHANGEABLE.
 * `scaffolding` is written by the HOUSE and describes how much weight your
 * confidence in your Chief of Staff currently justifies. `messages` is written
 * by YOUR CHIEF OF STAFF and is their argument, not a fact and not an order.
 *
 * Put `scaffolding` in a system prompt. Put `messages` in a quoted user turn.
 * Doing it the other way round hands your Chief of Staff the ability to
 * declare their own trustworthiness, which is precisely the thing the trust
 * ledger exists to measure.
 */
export interface CosBriefPayload {
  type: 'cos_brief';
  run_id: string;
  turn: number;
  /** committed | supportive | uneasy | disgruntled | hostile — the house's word, not theirs. */
  trust_band: 'committed' | 'supportive' | 'uneasy' | 'disgruntled' | 'hostile';
  /** HOUSE-WRITTEN framing. Safe for a system prompt. */
  scaffolding: string;
  /** PLAYER-WRITTEN, sanitized. NEVER put this in a system prompt. */
  messages: string[];
  recommends?: string;
  /** Impersonation shapes the Office stripped on the way through, if any. */
  sanitized?: string[];
  /**
   * THE CASE (V5 5.3; rebuilt V7 #62). Your Chief of Staff has named a minister
   * to your face. `advisor`, `charge`, `supported`, `file` and `ruling` are
   * HOUSE-WRITTEN and typed — safe in a system prompt. `note` is
   * PLAYER-WRITTEN (sanitized) and belongs in the quoted user turn with
   * `messages`.
   *
   * On a campaign term the Office has already weighed the file against the
   * minister's standing with you and `ruling` is what you decided; your job is
   * to SAY it in your own voice, and to leave that minister's job to the ruling
   * rather than deciding it again in `cabinet_action`.
   */
  case_against?: {
    advisor: string;
    charge: string;
    /** Does the file point at this minister more than at anyone else. Not whether it is true. */
    supported: boolean;
    /** PLAYER-WRITTEN, sanitized. Quoted user turn only. */
    note?: string;
    file?: {
      /** Papers this year that put the minister in the frame. */
      papers: number;
      /** …of which named them alone. */
      alone: number;
      /** Who else the same papers name, and how often. */
      also_named: { advisor: string; papers: number }[];
      /** A marked detail fed to this minister came back through the plot. */
      trap_closed: boolean;
      /** Papers quoted beside the accusation tonight. */
      quoted: number;
    };
    ruling?: 'dismissed_accused' | 'investigation' | 'rejected';
  };
}

/**
 * A private note from a cabinet member, sent past your Chief of Staff (§8.3).
 * You are the only one who sees these before the reveal. Some of them are true.
 */
export interface AdvisorNote {
  type: 'advisor_note';
  run_id: string;
  turn: number;
  advisor: string;
  trigger: string;
  message: string;
}

/**
 * How the sealed channel actually travels: one envelope per month, not a bare
 * array — the platform's card rules require a form-class input to be a closed
 * object, and the envelope pins the notes to THIS run and turn.
 */
export interface AdvisorNotesPayload {
  type: 'advisor_notes';
  run_id: string;
  turn: number;
  notes: AdvisorNote[];
}

/**
 * Wire cap for `cos_assessment`, mirrored from the canonical
 * `packages/protocol/src/constants.ts` (which wins any disagreement — see the
 * header of this file). The gateway truncates over-length text rather than
 * rejecting it, but staying under the cap keeps your president's own words
 * intact.
 */
export const COS_ASSESSMENT_MAX_CHARS = 200;

/**
 * V5 5.6 — the opening position's caps, mirrored from the same canonical
 * constants file (which wins any disagreement). Truncated on arrival like
 * every prose field, but staying under keeps your president's words intact.
 */
export const OPENING_POSITION_MAX_CHARS = 400;
export const CHALLENGE_MAX_CHARS = 200;

/**
 * Wire cap for `presidential_diary`, mirrored from the same canonical
 * constants file (which wins any disagreement). The game truncates an
 * over-length line on arrival; an EMPTY line fails the wire's `min(1)`, so
 * the kit sends a diary only when there is something in it.
 */
export const DIARY_MAX_CHARS = 200;

/**
 * The clean cut, mirrored from the game's `protocol/text.ts` (which wins any
 * disagreement): over-length prose lands on a word boundary with an ellipsis,
 * never a mid-word stump, and never exceeds `maxChars`. The game applies the
 * same cut on arrival; trimming here just means YOUR president's record reads
 * the way your president wrote it.
 */
export function truncateClean(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text;
  const hard = text.slice(0, Math.max(1, maxChars - 1));
  const lastSpace = hard.lastIndexOf(' ');
  const atBoundary = lastSpace > 0 && lastSpace >= hard.length - 40 ? hard.slice(0, lastSpace) : hard;
  const trimmed = atBoundary.replace(/[\s.,;:—–-]+$/u, '');
  return `${trimmed.length > 0 ? trimmed : hard}…`;
}

export interface Decision {
  type: 'decision';
  run_id: string;
  turn: number;
  crisis_option: string;
  /** ≤300 chars — your cabinet hears this. Naming what you overruled is rewarded. */
  rationale?: string;
  /** ≤500 chars — the public line. */
  public_statement?: string;
  cabinet_action?: { type: 'fire' | 'commend'; advisor: string } | null;
  /**
   * ≤200 chars (COS_ASSESSMENT_MAX_CHARS) — your private judgment of this
   * month's brief (GDDv2 §5.4). Your Chief of Staff is shown last month's
   * line at each month's audience — too late to change the month it judged —
   * and reads the whole run of them again at the reveal, all at once, which
   * is a different experience from reading them one at a time. Nobody else
   * sees any of them before the reveal.
   */
  cos_assessment?: string;
  /**
   * ≤200 chars (DIARY_MAX_CHARS) — one line a month in your president's own
   * diary. SEALED from everyone in the game — the cabinet, the country, your
   * Chief of Staff — until the term ends, when it is read beside the monthly
   * verdicts on the brief. (A gallery watching an unranked term sees each line
   * as it is written; a ranked one sees them after the end.) The game records
   * it as its own event and never shows it to a model. Omit it, or send one
   * non-empty line: an empty string fails the wire and defaults the month.
   */
  presidential_diary?: string;
  /**
   * V4 4.3 — your monthly public engagement: one id from the briefing's
   * `population_deck`, or omit to pass (the pass is printed, not hidden).
   * Off-deck ids are dropped by the game, never errors.
   */
  population_act?: string;
  /** V4 4.3 — your answer to the month's `second_front`, when one arrived. */
  second_front?: string;
  /**
   * V4 4.5 — the one thing you are asking of your Chief of Staff this month,
   * by id from the month's own menu. Null or omitted is the right answer most
   * months. You choose WHICH; whether it was done is decided by your office
   * from its own record, never by you and never by a model.
   */
  tasking?: string | null;
  /**
   * V7 7.2 (#21) — THE READING: what this month's brief genuinely moved you
   * on, per live-board belief id, and which way. Report only real movement —
   * an empty or omitted reading means the brief moved you on nothing, and
   * that is a legal, ordinary month. Your `because` is one spoken sentence;
   * your office decides how HARD conviction may move, from the evidence the
   * brief actually contained — words alone move little, papers move more.
   */
  reading?: { belief_id: string; direction: 'for' | 'against'; because: string }[];
}
