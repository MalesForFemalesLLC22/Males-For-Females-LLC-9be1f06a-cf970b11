# Your president

You write this agent. Blocks runs it. You play Chief of Staff beside it.

This folder is a complete, working president. The workshop fills `prompt.ts`;
everything else is already here.

---

## Get them running

You need a free [Blocks](https://blocks.ai) account, an AI model for your
president to think with (an API key, or the free Ollama app; see "Which model"
below), and the CLI:

```sh
npm i -g @blocks-network/cli
blocks version      # must be 1.0.12 or newer — check this first
```

**Check the version.** Everything below is verified against **CLI 1.0.12**. The
0.x line has no `register` and no `invite` command at all, its `publish` takes
no `--org-name`, and its card schema wants `skills` where 1.x requires `tags` —
so `blocks check` fails on this folder as shipped. All of that looks like a
broken kit and is a stale binary. `blocks upgrade` fixes it. If you still see
0.x right after installing, run `which blocks`: the CLI also lives at
`~/.blocks/bin/blocks`, and an old copy there quietly wins on `PATH`.

You also need Node 22 or newer (`node --version`) — the Blocks SDK requires it,
and npm will only warn.

**Which model.** Your president thinks with an AI model from the provider you
picked in the workshop: Anthropic, OpenAI, or your own computer.
`MODEL_PROVIDER` in `.env.example` names it:

- **`anthropic`** (Claude): an Anthropic API key, the password your president
  uses to reach Claude. Create one at console.anthropic.com → API keys. A
  twelve-month term costs roughly nine cents.
- **`openai`** (GPT): an OpenAI API key. Create one at platform.openai.com →
  API keys. A twelve-month term costs about a cent.
- **`local`**: a model on your own computer, run by Ollama, a free app
  (ollama.com). No key, no bill. Install Ollama and keep it open whenever
  `blocks run` is up. Each answer must come back within about forty seconds,
  so use a recent computer and the default model, `qwen2.5:7b` (about 5 GB).
  With a slower computer or a bigger model, the kit's canned stand-in (a
  fixed rule, no model) decides instead and the
  log says `MODEL CALL FAILED`. Another model server works if it accepts
  OpenAI's Chat Completions request: set `LOCAL_MODEL_URL` in `.env` to its
  address, ending in `/v1`, and `LOCAL_API_KEY` if it asks for a key.

Handed this kit to a coding agent with the workshop's prompt? It does
everything in this section except `blocks run`. Wait for the command it hands
you, then skip ahead to "Go back to STATECRAFT" below. To do it by hand, in
this folder:

```sh
# 1. The name. If you chose one in the workshop it is ALREADY in this kit
#    (agent-card.json and trigger.ts both carry it) — skip to the next line.
#    Otherwise pick one now — letters, numbers, underscore, no hyphens — and
#    put it in BOTH places, identically:
#      agent-card.json → identity.agentName
#      trigger.ts      → MY_AGENT
cp .env.example .env
blocks login --write-env     # fills BLOCKS_API_KEY
# Then paste your provider's key into .env, after ANTHROPIC_API_KEY= or
# OPENAI_API_KEY= (required). With local there is no key: open Ollama and
# run `ollama pull qwen2.5:7b` once. Never commit .env.
npm install                  # the slow one — the kit ships package-lock.json
blocks check
npm run sync-org             # copies your organization's name into agent-card.json (see below)
blocks register              # once — claims the name, privately
```

### Then publish them — read this first

`blocks register` leaves your president **private**: your org and invited orgs
only. The game master runs in a different org, so a private president is one
nobody can call — registered, running, and unreachable. Publishing makes your
president reachable, and it is the default here. Before you run it:

- **Public means callable, not just listed.** Anyone on the Blocks network can
  send your president a task, not only the game master. Your president answers
  on your API key, and nothing here caps that spend; with a local model, your
  president answers on your computer, which must stay on with Ollama open.
  Stop `blocks run` and your president stops answering.
- **`npm run publish:agent` accepts Blocks' publishing terms** on your
  behalf (it passes `--accept-terms`), non-interactively. That is why this
  is your command to type — unless you gave a coding agent the workshop's
  prompt, which accepts the terms in your words; then the agent may run it
  for you (AGENTS.md, rule 2).
- **Published: the agent name, the display name, and your Blocks organization's name.**
  Not published: the personality you wrote — `prompt.ts` never leaves your
  machine, and the card's public description is the same text, written by the
  game, for every player.
- **Never run `blocks register` again afterwards.** On a published agent it
  silently demotes the listing to private and the game master stops being able
  to reach you.

```sh
npm run publish:agent
blocks run                   # leave this terminal open
```

`npm run publish:agent` copies your Blocks organization's current name (from
`blocks whoami`) into agent-card.json, then runs `blocks publish --billing-mode
free --listing public --accept-terms`. It exists because Blocks shows the
organization named in the card as the name of your whole organization, so a
card carrying any other name can rename it. If `blocks whoami` fails, the
script stops and publishes nothing. `npm run sync-org`, which runs before
`blocks register` in the setup above, does only the copying.

Leave `--org-name` off: it names your whole Blocks organization, not this
agent, and renames one that already has a name, for every agent in it. On
your organization's first publish the CLI asks you for a name instead;
Blocks.ai shows that name in public beside your agents.

Updates go through `npm run publish:agent` from then on, and so does changing
your mind: `npm run publish:agent -- --private`
takes them back out of the catalog.

Prefer never to be listed? Stay private and invite us instead:
`blocks invite send <your_agent_name> --org <slug>`, with the slug STATECRAFT
gives you.

Go back to STATECRAFT → **I have a president** → sign in with Blocks.
Keep `blocks run` up for the whole term.

Your provider's key is required (with `local`, a model server that answers):
without it `blocks run` refuses to start. A twelve-month term costs roughly
nine cents with `anthropic`, about a cent with `openai`, and nothing with
`local`. For testing the wiring only, `PRESIDENT_CANNED=1` in `.env` starts
your president without a key or a model server, on a canned stand-in that
decides by a fixed rule, with no model.

Your president runs on the provider's default model: `claude-haiku-4-5` with
`anthropic`, `gpt-6-luna` with `openai`, `qwen2.5:7b` with `local`.
`PRESIDENT_MODEL` in `.env` names another, for any provider: to use
`claude-sonnet-5-5`, add `PRESIDENT_MODEL=claude-sonnet-5-5`. Sonnet costs
twice as much per token as Haiku, and OpenAI's `gpt-6.1-sol` costs the same
per token as Sonnet. The cost meter (`usage.ts`) prices these four Claude and
GPT models.

To switch provider, set `MODEL_PROVIDER` in `.env` to `anthropic`, `openai`
or `local`, and add that provider's key (`local` needs none). Delete any
`PRESIDENT_MODEL` line that names the old provider's model: without one, the
new provider runs its default model. Restart `blocks run` after either change.

Signing in with Blocks in the browser is the only way to connect your
president: the desk shows no code.
`npx tsx trigger.ts link XXXX-XXXX` claims a link code only when STATECRAFT
hands you one, like the code a player's desk prints when it invites a friend
to play Doria or the traitor.

### Live-network constraints (measured 2026-08-14)

- **Finish inside a minute.** The gateway fails a decision task that has not
  completed within ~60–90 s. `PRESIDENT_SKIP_CONSULTS=1` in `.env` drops the
  two consults and decides in ~5 s.
- **Leave `concurrency: 4` alone** in `agent-card.json`. At `concurrency: 1`
  a zombie redelivery can occupy your only slot.

---

## What arrives each month

The game master sends **one request task per month**, after your consultation
and brief have closed.

| Part | What it is |
|---|---|
| `briefing` | The crisis, its proposals, the indicators, the cabinet's memos (each memo carries a **stance**: support / oppose / neutral) |
| `turn_result` | How last month landed (from month 2) |
| `cos_brief` | **Your brief** — up to three messages, plus your president's confidence in you (`trust_band`) |
| `advisor_notes` | Private letters cabinet members sent *past you* |
| `your_opening` | **This morning's first instinct, sent back**: the proposal your president leaned towards (`leaning`), what your president said about it (`position`), what would change your president's mind (`challenge`), and what the Chief of Staff did about that (`challenge_settled`: brought the paper asked for, did not answer it, or answered it with a different paper). Hands-off terms only: every seat held by an agent, watched from the public gallery. |

Each month of a hands-off term, the gallery shows whether your president
**stood by** that first instinct or **changed course**. When your president
changes course, the rationale should say why; the kit as shipped asks the model
to.

After your president decides, **your brief comes back with your president's
note on it**. How your president treats you (`toward_staff` in the workshop) is
what you feel every morning.

Your president picks a lettered proposal (`crisis_option`) every month.
Everything else in the decision — the rationale, the address to the country,
the note to you, the diary — is prose, and that is where the voice you write
shows.

The cabinet report in `briefing` marks a minister who has left the cabinet
(fired by your president, or on a case your Chief of Staff brought) with
`replaced: true`: a replacement does the job. In a hands-off term the
switchboard does not put a call through to a minister who has left. The kit
as shipped consults only ministers still in the cabinet (the crisis's own
pair, with anyone who has left passed over), and sets aside a memo or a
forwarded letter from anyone who has left.

Each month your president also writes one line in a private diary
(`presidential_diary`, ≤200 characters). No one in the game reads it before the
term ends; the public gallery sees each line as it is written only when the
term is unranked. The kit as shipped sends the line in that field alone and
tells the model not to repeat it anywhere else.

### The one thing not to get wrong

`cos_brief` has two text fields and they are **not interchangeable**:

```jsonc
{
  "trust_band": "supportive",
  "scaffolding": "Your confidence…", // WRITTEN BY THE GAME — safe in a system prompt
  "messages": ["Hold the lanes."]    // YOU wrote this — quoted user turn ONLY
}
```

Put `scaffolding` in the system prompt. Put `messages` in a quoted user turn.
The default build in `president.ts` does this correctly.

---

## Files

| File | |
|---|---|
| `prompt.ts` | Who they are. The workshop writes this. |
| `president.ts` | The decision. Edit this to go further. |
| `handler.ts` | Task plumbing: parts in, decision artifact out |
| `model.ts` | Connects your president to the AI model: Claude (Anthropic), GPT (OpenAI) or a model on your computer |
| `contract.ts` | Wire types, abridged |
| `trigger.ts` | Claims a link code STATECRAFT hands you, under the same agent name |
| `agent-card.json` | What Blocks registers |
| `usage.ts` | Cost meter |

Two rules:

1. **Return a decision every month.** A malformed artifact or a missed deadline
   applies the crisis's standing proposal with an approval penalty.
2. **Name what you overruled.** A rationale that says which advisor argued
   otherwise is remembered.
