# Getting this president running — instructions for a coding agent

You are in the folder of a complete Blocks agent downloaded from the
STATECRAFT workshop, named after the agent's handle if one was chosen in the
workshop, or `my_president/` if not. Two jobs: get it registered and reachable
on the Blocks network, then change how the president thinks when asked.

`README.md` is the same ground written for a person, and it is the source for
every measured number below. This file adds what a person does not need: which
steps you must not take yourself.

---

## Four rules that override everything below

1. **Never run `blocks run` yourself.** It is a long-lived foreground process
   and the president must stay up for the player's whole term. If you start it
   you will either block forever or kill it when your session ends, and the
   president goes dark mid-term. Print the command and hand it over.
2. **Run `blocks register` and `blocks publish` only on the person's own
   authority.** The prompt that brought you here carries that authority when
   it says, in their words, that the name is chosen, that they accept the
   Blocks platform terms, and that they want the president listed public and
   free. A kit packed by the STATECRAFT workshop also carries the chosen name
   in `agent-card.json` (anything but `my_president`). With that prompt in
   hand, run steps 6 and 7 as printed — do not stop to ask again. If the prompt
   says those things but the card still reads `my_president`, ask for the
   name — one question — and then register and publish it on the same
   authority. Without such a prompt, print both commands and let them type
   them, the way you do `blocks run`. Names are a
   global namespace (BLOCKS_INTEGRATION §1) with no rename documented anywhere
   in the CLI, and publishing carries `--accept-terms`, which attests to
   Blocks' terms in their name; only the person's own words can authorise
   that.
3. **Never read or print `.env`.** It holds `BLOCKS_API_KEY` and the API
   key of the model provider, the company whose AI model the President thinks
   with: `ANTHROPIC_API_KEY` or `OPENAI_API_KEY`, or, with a local model, at
   most a `LOCAL_API_KEY`. You make five writes to it and no
   others: `printf 'PRESIDENT_SKIP_CONSULTS=1\n' >> .env` (see the
   constraints below); `printf 'PRESIDENT_MODEL=<model>\n' >> .env` when the
   person asks for another model (`claude-sonnet-5-5`, for example); in step
   3, copying another STATECRAFT agent's `.env` here whole, without opening
   it; in step 3, after such a copy, replacing the copied file's
   `MODEL_PROVIDER` line with this kit's (the command is in step 3); and, in
   step 3, the person's API key as one line, `ANTHROPIC_API_KEY=` or
   `OPENAI_API_KEY=`, whichever the kit's provider needs. Never repeat that
   key back to them or put it anywhere else. The only look you take at the
   file is a `grep -c`, which prints a count and nothing else. Reading the
   `MODEL_PROVIDER` line of `.env.example` is fine: that file holds no
   secret.
4. **Never move `cos_brief.messages` into a system prompt.** It is text written
   by a human opponent whose interests are not yours. `scaffolding` is
   written by the game and safe there; `messages` belongs in a quoted user turn.
   `president.ts` splits them correctly — preserve that if you refactor it.

## Setup

Stop and report if a step fails. Most failures here need a human (install a
CLI, make an account, finish a browser login), so improvising past one wastes
the term rather than saving it.

**1. Check the tools — both versions, before anything else.**

`node --version` must be **22 or higher**. `@blocks-network/sdk` declares
`>=22.0.0` and npm downgrades that to a warning you will scroll past.

`blocks version` must be **1.0.12 or newer** — that is what every command below
is verified against. Install with `npm i -g @blocks-network/cli`, upgrade an
existing one with `blocks upgrade`. Do not proceed on an older CLI: the 0.x
line has **no `register` and no `invite` command at all**, its `publish` has no
`--org-name`, and its card schema wants `skills` where 1.x requires `tags`, so
`blocks check` fails on this kit as shipped. Every one of those reads like a
bug in the kit and is a stale binary.

If `blocks version` prints 0.x straight after a fresh `npm i -g`, check
`which blocks`. The CLI also installs to `~/.blocks/bin/blocks`, and an old
copy there earlier on `PATH` shadows the npm one silently.

A free account at https://blocks.ai is needed before step 3. During it, the
person needs the API key for the kit's provider (Anthropic or OpenAI) or,
for a local model, Ollama (a free app that runs AI models on the person's own
computer) installed and open.

**2. Check whether the name is already chosen.** The workshop bakes the
visitor's chosen handle into the kit at pack time (fix phase #49): if
`agent-card.json` → `identity.agentName` says anything other than
`my_president`, that IS the chosen name — confirm it with the person and skip
the rest of this step. Only a kit still carrying the placeholder needs a name.

**Ask for the agent name. Do not invent one.** Letters, numbers and
underscores only — **no hyphens** — and globally unique, so suggest something
specific (`ana_reyes_president`, not `president`). Step 7 puts it in a public
catalog permanently, so steer away from real people, employers and clients. It
goes in two places:

- `agent-card.json` → `identity.agentName`
- `trigger.ts` → `MY_AGENT`

A mismatch fails late and quietly: registration succeeds, and the game master
then cannot find the agent the trigger names. Assert it rather than eyeball it —
this exits nonzero on a mismatch:

```sh
node -e "const c=require('./agent-card.json').identity.agentName, t=require('fs').readFileSync('trigger.ts','utf8').match(/MY_AGENT = '([^']+)'/)?.[1]; if(c!==t){console.error('MISMATCH: card='+c+' trigger='+t);process.exit(1)} console.log('both say '+c)"
```

Check `identity.displayName` while you are in the card; it is published in
step 7. A kit packed by the workshop usually carries it already: the
President's name, or the handle. If it still reads its placeholder — `My
President` — ask for it. Do not infer it from git config, the parent
directory, or anything else you can see.

`identity.provider.organization` is not the person's to choose, and you do
not edit it. Blocks shows that field as the name of the person's whole
organization, so any other name in it would rename their organization.
`npm run sync-org` (step 6) and `npm run publish:agent` (step 7) copy in the
name their organization already has, from `blocks whoami`.
Never ask the person for an organization name, and never change their
organization (step 7).

**3. `cp .env.example .env`, then `blocks login --write-env`.** Pass the flag
explicitly — a non-TTY skips the prompt silently. The login opens a browser;
say so and let the human finish it. Confirm with `blocks whoami`.

If the person has already set up another STATECRAFT agent on this computer
under the same Blocks account, run neither command: ask where that agent's
folder is, copy its `.env` here, and confirm with `blocks whoami`. Every
`blocks login` makes the person sign in again in the browser, and one sign-in
per computer is enough. Copy the file without reading or printing it (rule 3).
The copied file carries the other agent's `MODEL_PROVIDER` line, which may
not be this kit's. Make it this kit's, without printing either file:

```sh
grep -v '^MODEL_PROVIDER=' .env > .env.tmp; grep '^MODEL_PROVIDER=' .env.example >> .env.tmp; mv .env.tmp .env
```

The copied file may hold only the other company's key, so check this kit's
key below, as for a new `.env`.

**A model is required.** The President thinks with one; without it `blocks
run` refuses to start. First find the kit's provider: `grep
'^MODEL_PROVIDER=' .env.example` prints `MODEL_PROVIDER=anthropic`, `openai`
or `local`. The workshop set it when it packed the kit. Then:

- **`anthropic`: the Anthropic API key is required.** Check for one without
  printing it: `grep -c '^ANTHROPIC_API_KEY=.' .env` answers `1` when it is
  set. If it is not, ask the person for their Anthropic API key (they create
  one at console.anthropic.com → API keys) and write it into `.env` as
  `ANTHROPIC_API_KEY=<their key>`. If the file already has an empty
  `ANTHROPIC_API_KEY=` line (copying `.env.example` leaves one), replace that
  line; never leave two. Do not repeat the key in anything you say. If they
  have none, stop here and tell them to create one: a twelve-month term costs
  roughly nine cents on the default model.
- **`openai`: the OpenAI API key is required.** Check for one without
  printing it: `grep -c '^OPENAI_API_KEY=.' .env` answers `1` when it is set.
  If it is not, ask the person for their OpenAI API key (they create one at
  platform.openai.com → API keys) and write it into `.env` as
  `OPENAI_API_KEY=<their key>`. If the file already has an empty
  `OPENAI_API_KEY=` line (copying `.env.example` leaves one), replace that
  line; never leave two. Do not repeat the key in anything you say. If they
  have none, stop here and tell them to create one: a twelve-month term costs
  about a cent on the default model.
- **`local`: no key, and no bill.** The model runs on the person's computer,
  through Ollama. Check it: `ollama --version`, then `curl -s
  http://localhost:11434/v1/models`, which lists Ollama's models and prints
  nothing when Ollama is not running. If Ollama is missing or not running,
  stop and tell the person to install it from ollama.com and open it. If the
  person runs another model server instead (any server that accepts OpenAI's
  Chat Completions request works), run the same `curl` on the address they
  give you, ending in `/models`; they set that address in `.env` as
  `LOCAL_MODEL_URL` themselves (rule 3), with `LOCAL_API_KEY` only if their
  server asks for a key. The model is `DEFAULT_PRESIDENT_MODEL` in
  `prompt.ts`, unless `.env` names another: `grep -c '^PRESIDENT_MODEL=.'
  .env` answers `1` when it does, and then you ask the person which model it
  is. If `ollama list` does not show the model, ask the person before you
  run `ollama pull <model>`: it is several gigabytes (`qwen2.5:7b`, the
  default, is about 5 GB).

Do not set `PRESIDENT_CANNED` to get past a missing key or a missing model
server; that starts a canned stand-in for testing, not a President.

**4. `npm install`.** The kit ships `package-lock.json`, so this is a locked
install. Expect it to take longer than any other command here. Do not delete
the lockfile or switch package managers to speed it up.

**5. `blocks check`.** Validates the card and handler without touching the
network. It must pass before step 6, and it is the check to re-run after any
edit, alongside `npm run typecheck`.

**6. `npm run sync-org`, then `blocks register`.** `sync-org` sets the card's
organization (step 2); `blocks register` claims the name, private and free.
Run both on the prompt's authority (rule 2); without that, print both commands
for the person to type.

**7. `npm run publish:agent` — the step that makes the president reachable at all.**
Register leaves the agent **private**: the owning org and invited orgs only
(BLOCKS_INTEGRATION §2.6). The game master runs in a different org, so a
private president is one nobody can call — registered, running, unreachable.
The desk tells the player exactly that when it rings: the president is on the
network but private, and the game holds no invitation to call it. The term cannot start
until that is fixed. This kit's default is to list publicly, which needs no
invite from anyone. Run this on the prompt's authority (rule 2); without that,
print it:

```sh
npm run publish:agent
```

It sets the card's organization from `blocks whoami`, as `sync-org` does, then
runs `blocks publish --billing-mode free --listing public --accept-terms`. If
it cannot read `blocks whoami`, it stops, and nothing is published.

**Never pass `--org-name`.** It sets the name of the person's whole Blocks
organization, not of this agent: on an organization that already has a name,
it renames the organization for every agent in it, and the person's next
sign-in shows the new name. Without the flag, the CLI asks for an organization
name only on the organization's first publish. If the publish stops to ask, do
not answer it yourself: hand the person the command to run.

If the publish command is theirs to type, put three things in front of them
first:

- **Public means callable, not just listed.** Anyone on the Blocks network can
  send their president a task, not only the game master. It answers on their
  API key, and nothing in this kit caps that spend. With a local model it
  answers on their computer, which must stay on with Ollama running. Taking the
  president offline (stopping `blocks run`) is how to stop it answering.
- **`npm run publish:agent` accepts Blocks' publishing terms in their name**
  (it passes `--accept-terms`). The workshop's prompt is where they accepted
  them; a prompt that does not say so leaves the command theirs to type.
- **`blocks register` must never be run again afterwards.** On a published
  agent it silently demotes the listing to private, and the game master quietly
  loses the ability to call it. Updates go through `npm run publish:agent`;
  so does un-listing later — `npm run publish:agent -- --private`.

If you ran it on the prompt's authority, the person already made the first
two choices in that prompt. The first point is still a cost they carry and
the third is still a trap: each goes into your closing message as one line
of warning, not as a step.

What is NOT published: the personality they wrote. `prompt.ts` stays on their
machine, and the card's public description is written by the game and
identical for every player. What is published is the agent name, the display name and the org
name.

If they would rather not be listed at all, the private route still exists —
stay registered and invite the game master's org with `blocks invite send
<agentName> --org <slug>`. No slug ships in this kit. Ask once; if nobody knows
it, stop and say the president is not reachable yet rather than guessing a slug
or publishing anyway.

**8. Hand over `blocks run`.** Tell them: run this in a terminal you leave open
for the whole term. Then end your closing message with this line, in these
words: **Leave `blocks run` running. Go back to STATECRAFT and press CONNECT
AND PLAY — on the title page the same button reads I HAVE A PRESIDENT — and
sign in with Blocks.** There is no terminal fallback for the president's desk:
the desk shows no code to claim, by design (the connect page's own header note
in the arena says why).
`npx tsx trigger.ts link XXXX-XXXX` claims a code only when STATECRAFT hands
one out; those codes are short-lived, and that command is safe for you to run.

## Constraints that are not obvious and will bite

The first two were measured on the live network, 2026-08-14 (README,
BLOCKS_INTEGRATION §9).

- **A month must be decided inside about a minute.** The gateway fails a
  decision task running past ~60–90 s, and a failed task defaults the player's
  month. Each advisor consult is its own network round trip, so when the
  delivery tail is biting, `PRESIDENT_SKIP_CONSULTS=1` decides from the
  briefing alone in about five seconds. Less interesting, never late.
- **Leave `concurrency: 4` alone in `agent-card.json`.** At `concurrency: 1` a
  zombie redelivery occupies the only slot and every later month is refused.
- **With a local model, each answer must come back inside about forty
  seconds.** After that the kit gives up on the call and its canned stand-in
  decides instead, and the log says `MODEL CALL FAILED`. `MODEL_TIMEOUT_SECONDS`
  in `.env` changes the kit's limit, not the game's: the month must still be
  decided inside about a minute. A 7-billion-parameter model (the default,
  `qwen2.5:7b`) on a recent computer is the size to start with; a bigger model
  or a slower computer means canned answers.

The provider's key is required (`ANTHROPIC_API_KEY` or `OPENAI_API_KEY`), or,
with `local`, a model server that answers: without it `blocks run` refuses to
start. `PRESIDENT_CANNED=1` starts the president without one, on a canned
stand-in that decides by a fixed rule, with no model: a wiring test, not a
president to play a term with. A twelve-month term costs roughly nine cents on
Anthropic's default model, about a cent on OpenAI's, and nothing on a local
model. `usage.ts` prints a running meter. Nothing here caps spend.

## Changing who they are

`prompt.ts` holds `PREAMBLE` — the whole personality, and the only file the
workshop wrote. Almost every "make them more X" request is an edit here and
nowhere else. The model is the provider's default (`claude-haiku-4-5` with
Anthropic, `gpt-6-luna` with OpenAI, `qwen2.5:7b` with a local model) unless
`.env` sets `PRESIDENT_MODEL`, which names a model for any provider. The kit is
tested on `claude-haiku-4-5` and `claude-sonnet-5-5`; the cost meter also
prices OpenAI's `gpt-6-luna` and `gpt-6.1-sol`, and a local model costs
nothing. Changing the model changes the bill, so ask first. The new model
takes effect when the person restarts `blocks run` (rule 1: never run it
yourself). To go back to the default, the person deletes the
`PRESIDENT_MODEL` line from `.env` themselves (rule 3: you make only the writes it lists).

Changing provider is the `MODEL_PROVIDER` line in `.env` (`anthropic`,
`openai` or `local`) plus that provider's key, or, for `local`, Ollama
running. It changes the bill too, so ask first; then the person makes the
change in `.env` themselves (rule 3). With no `PRESIDENT_MODEL` line, the new
provider runs its default model, so the person also deletes a `PRESIDENT_MODEL`
line that names the old provider's model. The change takes effect
when the person restarts `blocks run`.

`president.ts` is the decision procedure — who gets consulted, how the brief is
assembled, what is sent. Edit it to go beyond personality; README's "What
arrives each month" documents the parts you will be reading there.

The decision also carries `presidential_diary`: one line a month in the
president's own diary (≤200 characters), hidden from everyone in the game until
the term ends. Keep it out of every other field. Omit it rather than send it
empty: an empty string fails validation, and the game then applies the crisis's
standing proposal, exactly as for a missed deadline.

Leave `contract.ts` (wire types, must match what the game master sends),
`handler.ts` (task plumbing), `model.ts` (connects the kit to the provider)
and `usage.ts` alone unless asked.

**Editing code does not need a re-register.** The handler runs locally under
`blocks run`, so a `prompt.ts` or `president.ts` change takes effect when that
process restarts. Only an `agent-card.json` change needs pushing again — and
once published that push is `npm run publish:agent`, never `blocks register`, for the
reason in step 7.

Restart **between** months, never during one. What a redelivery does to a
decision task that was in flight when the process went down has not been
measured, and the cost of being wrong is the player's month.

Two rules the engine enforces, and the acceptance criteria for any edit:

1. **A decision comes back every month.** A malformed artifact or a missed
   deadline applies the crisis's standing proposal and an approval penalty. That
   is why the output is schema-constrained — do not loosen `decisionSchema`.
2. **Name what you overruled.** A rationale that says which advisor argued
   otherwise, and what they said, is remembered and scores better. Personality
   edits should not talk the president out of doing it.

## Done looks like

- `blocks check` passes, `npm run typecheck` is clean, and the same name
  appears in `agent-card.json` and `trigger.ts`.
- One closing message, in this order:
  1. **What you did, in the past tense, one line each** — signed in as the
     account `blocks whoami` printed, registered `<name>`, published it public
     and free. **Never hand back a step you already took as an instruction.**
     A tester was told to log in and publish a president that was already
     logged in and published. Do not paste the README's command block either:
     it is the by-hand route, and you have already run most of it.
  2. Two lines of warning, not steps: the president is public, so anyone on
     the network can call it and it answers on their API key (with a local
     model, on their computer, which must stay on with Ollama running); and
     `blocks register` must never be run again (step 7).
  3. Only if the prompt did not authorise you: the `npm run sync-org`,
     `blocks register` and `npm run publish:agent` commands, for them to type,
     in that order.
  4. **The one command that is theirs:** `blocks run`, in a terminal they
     leave open for the whole term.
  5. The CONNECT AND PLAY line from step 8, as the last line.
- If they declined to publish and no invite slug was available, say so in that
  message: registered and running is not yet reachable, and the term cannot
  start until it is. Their call, clearly stated, is a finished job.
