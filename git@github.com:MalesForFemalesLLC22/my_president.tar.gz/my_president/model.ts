/**
 * Which model your agent thinks with: Anthropic's Claude, OpenAI's GPT, or a
 * model running on your own computer. This one file connects the kit to all
 * three.
 *
 * The rest of the kit asks for an answer in Anthropic's request shape — a
 * system prompt, one user turn, and a JSON schema the answer must fit — and
 * reads Anthropic's answer shape back. For `anthropic`, this file hands over
 * Anthropic's own client, untouched. For `openai` and `local`, it hands over
 * a stand-in with the same `messages.create`, which turns the request into
 * the Chat Completions request that OpenAI and local model servers (Ollama,
 * LM Studio, llama.cpp) all accept, and turns the answer back.
 *
 * Set the provider with MODEL_PROVIDER in .env (the workshop sets the kit's
 * default in prompt.ts when it packs your kit):
 *   - anthropic — needs ANTHROPIC_API_KEY;
 *   - openai    — needs OPENAI_API_KEY;
 *   - local     — needs a model server on this computer; LOCAL_MODEL_URL says
 *                 where (Ollama's address when unset). Any server that accepts
 *                 OpenAI's Chat Completions request works, including a hosted
 *                 one: set LOCAL_API_KEY if it asks for a key.
 *
 * This file is the same in every STATECRAFT kit.
 */

import type { Anthropic } from '@anthropic-ai/sdk';

export const PROVIDERS = ['anthropic', 'openai', 'local'] as const;
export type Provider = (typeof PROVIDERS)[number];

/** Where a local model server listens when LOCAL_MODEL_URL is unset: Ollama's address. */
export const LOCAL_MODEL_URL_DEFAULT = 'http://localhost:11434/v1';

const OPENAI_URL = 'https://api.openai.com/v1';

/**
 * How long one model call may take before the kit gives up on it and its
 * canned stand-in answers instead. The game waits about forty-five seconds
 * for an answer, so a late one is wasted. MODEL_TIMEOUT_SECONDS in .env
 * changes it. Anthropic's client keeps its own timeouts.
 */
const DEFAULT_TIMEOUT_SECONDS = 40;

/** How long one OpenAI or local call may take: MODEL_TIMEOUT_SECONDS, else the default above. */
function timeoutSeconds(env: NodeJS.ProcessEnv): number {
  const set = Number(env['MODEL_TIMEOUT_SECONDS']);
  return Number.isFinite(set) && set > 0 ? set : DEFAULT_TIMEOUT_SECONDS;
}

/** The provider named in `raw` (MODEL_PROVIDER), else `fallback`. A name the kit does not know also gives `fallback`; `setupProblem` reports it. */
export function readProvider(raw: string | undefined, fallback: Provider): Provider {
  const value = raw?.trim().toLowerCase() ?? '';
  return (PROVIDERS as readonly string[]).includes(value) ? (value as Provider) : fallback;
}

/** What a kit says about itself in the lines below. */
export interface Who {
  /** The log prefix, e.g. `[president]`. */
  readonly tag: string;
  /** e.g. `your President`. */
  readonly noun: string;
  /** The .env line that names the model, e.g. `PRESIDENT_MODEL`. */
  readonly modelVar: string;
  /** The .env line that starts the canned stand-in, e.g. `PRESIDENT_CANNED`. */
  readonly cannedVar: string;
}

/**
 * Why `blocks run` cannot start yet, as the lines to print, or null when
 * nothing is missing. A local server is checked separately (`checkLocalServer`),
 * because that check has to wait for an answer.
 */
export function setupProblem(provider: Provider, who: Who, env: NodeJS.ProcessEnv = process.env): string[] | null {
  const raw = env['MODEL_PROVIDER']?.trim() ?? '';
  if (raw !== '' && !(PROVIDERS as readonly string[]).includes(raw.toLowerCase())) {
    return [
      `${who.tag} Not starting: MODEL_PROVIDER in .env is "${raw}". It must be anthropic, openai or local.`,
    ];
  }
  if (provider === 'anthropic' && !env['ANTHROPIC_API_KEY']) {
    return [
      `${who.tag} Not starting: ANTHROPIC_API_KEY is not set, and ${who.noun} needs it to think.`,
      '  Create a key at console.anthropic.com → API keys, add it to this folder’s .env as',
      '  ANTHROPIC_API_KEY=…, then run `blocks run` again.',
    ];
  }
  if (provider === 'openai' && !env['OPENAI_API_KEY']) {
    return [
      `${who.tag} Not starting: OPENAI_API_KEY is not set, and ${who.noun} needs it to think.`,
      '  Create a key at platform.openai.com → API keys, add it to this folder’s .env as',
      '  OPENAI_API_KEY=…, then run `blocks run` again.',
    ];
  }
  return null;
}

/** The address of the local model server: LOCAL_MODEL_URL, else Ollama's. */
export function localModelUrl(env: NodeJS.ProcessEnv = process.env): string {
  return (env['LOCAL_MODEL_URL']?.trim() || LOCAL_MODEL_URL_DEFAULT).replace(/\/+$/, '');
}

/** The sentence a failed model call ends on: what to look at first. */
export function whatToCheck(provider: Provider, model: string, env: NodeJS.ProcessEnv = process.env): string {
  if (provider === 'openai') return 'Check OPENAI_API_KEY in .env, and the credit on your OpenAI account.';
  if (provider === 'local') {
    return `Check that your model server is running at ${localModelUrl(env)} and has the model ${model}. If it is running, the model may be too slow: each answer must come back within ${timeoutSeconds(env)} seconds, and a smaller model answers faster.`;
  }
  return 'Check ANTHROPIC_API_KEY in .env, and the credit on your Anthropic account.';
}

// ---------------------------------------------------------------------------
// The client
// ---------------------------------------------------------------------------

/** The one call the kit makes, in Anthropic's shape. Anthropic's own client fits it. */
export interface ModelClient {
  readonly messages: {
    create(params: Anthropic.MessageCreateParamsNonStreaming): Promise<Anthropic.Message>;
  };
}

/** The client for `provider`. Anthropic's SDK is loaded on the first call, so the other two never load it. */
export function createModelClient(provider: Provider, env: NodeJS.ProcessEnv = process.env): ModelClient {
  if (provider === 'anthropic') {
    let client: Promise<Anthropic> | undefined;
    return {
      messages: {
        create: async (params) => {
          client ??= import('@anthropic-ai/sdk').then((sdk) => new sdk.default());
          return (await client).messages.create(params);
        },
      },
    };
  }
  return chatCompletionsClient({
    provider,
    url: provider === 'openai' ? OPENAI_URL : localModelUrl(env),
    key: provider === 'openai' ? (env['OPENAI_API_KEY'] ?? '') : (env['LOCAL_API_KEY'] ?? ''),
    timeoutMs: timeoutSeconds(env) * 1000,
    ...(env['OPENAI_REASONING_EFFORT']?.trim() ? { reasoningEffort: env['OPENAI_REASONING_EFFORT'].trim() } : {}),
  });
}

/**
 * The lowest reasoning effort each OpenAI model accepts. These models think
 * before they answer unless told not to, which costs time and tokens the
 * game's short calls do not need. A model not listed here thinks at its own
 * default; OPENAI_REASONING_EFFORT in .env sets it for any model.
 */
const OPENAI_LEAST_EFFORT: Readonly<Record<string, string>> = {
  'gpt-6-luna': 'none',
  'gpt-6.1-sol': 'low',
  'gpt-6-sol': 'low',
  'gpt-5-mini': 'minimal',
  'gpt-5-nano': 'minimal',
  'gpt-5': 'minimal',
};

/** Room for a model's thinking, on top of the answer's own token budget. Only tokens used are billed. */
const THINKING_ROOM_TOKENS = 8_000;

interface ChatOptions {
  readonly provider: 'openai' | 'local';
  readonly url: string;
  readonly key: string;
  readonly timeoutMs: number;
  readonly reasoningEffort?: string;
  /** For tests: the network. */
  readonly fetch?: typeof fetch;
}

interface ChatResponse {
  choices?: { message?: { content?: string | null; refusal?: string | null }; finish_reason?: string }[];
  usage?: {
    prompt_tokens?: number;
    completion_tokens?: number;
    prompt_tokens_details?: { cached_tokens?: number } | null;
  };
}

/**
 * OpenAI refused the strict form of a schema once; from then on this process
 * sends the schema unenforced (the kit still checks every answer).
 */
let strictRefused = false;

export function chatCompletionsClient(options: ChatOptions): ModelClient {
  const send = options.fetch ?? fetch;
  return {
    messages: {
      create: async (params) => {
        const format = (params as { output_config?: { format?: { schema?: Record<string, unknown> } } }).output_config?.format;
        const schema = format?.schema;
        const strict = options.provider === 'openai' && schema !== undefined && !strictRefused;
        const body = chatBody(params, options, schema, strict);
        let response = await post(send, options, body);
        if (!response.ok && response.status === 400 && strict) {
          const text = await response.text();
          if (!/schema|response_format/i.test(text)) throw httpError(options, response.status, text);
          strictRefused = true;
          console.warn(
            `[model] OpenAI refused this kit's answer format in strict mode. Until \`blocks run\` restarts, the kit asks OpenAI without strict mode and checks each answer itself. ${text.slice(0, 300)}`,
          );
          response = await post(send, options, chatBody(params, options, schema, false));
        }
        if (!response.ok) throw httpError(options, response.status, await response.text());
        const data = (await response.json()) as ChatResponse;
        const choice = data.choices?.[0];
        const refusal = choice?.message?.refusal;
        if (typeof refusal === 'string' && refusal !== '') throw new Error(`the model refused: ${refusal.slice(0, 300)}`);
        const content = choice?.message?.content;
        if (typeof content !== 'string' || content.trim() === '') {
          throw new Error(`the model returned no answer (finish_reason ${String(choice?.finish_reason)})`);
        }
        const text = answerText(content, strict ? schema : undefined);
        const cached = data.usage?.prompt_tokens_details?.cached_tokens ?? 0;
        return {
          id: 'chat',
          type: 'message',
          role: 'assistant',
          model: params.model,
          content: [{ type: 'text', text, citations: null }],
          stop_reason: choice?.finish_reason === 'length' ? 'max_tokens' : 'end_turn',
          stop_sequence: null,
          usage: {
            input_tokens: Math.max(0, (data.usage?.prompt_tokens ?? 0) - cached),
            output_tokens: data.usage?.completion_tokens ?? 0,
            cache_creation_input_tokens: 0,
            cache_read_input_tokens: cached,
          },
        } as unknown as Anthropic.Message;
      },
    },
  };
}

async function post(send: typeof fetch, options: ChatOptions, body: Record<string, unknown>): Promise<Response> {
  const attempt = (): Promise<Response> =>
    send(`${options.url}/chat/completions`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(options.key !== '' ? { authorization: `Bearer ${options.key}` } : {}),
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(options.timeoutMs),
    });
  const first = await attempt();
  // One retry, a second later, when the server is busy or briefly down.
  if (first.status === 429 || first.status >= 500) {
    await new Promise((resolve) => setTimeout(resolve, 1_000));
    return attempt();
  }
  return first;
}

function httpError(options: ChatOptions, status: number, text: string): Error {
  const where = options.provider === 'openai' ? 'OpenAI' : `the model server at ${options.url}`;
  return new Error(`${where} answered ${status}: ${text.slice(0, 300)}`);
}

/** Anthropic's request, as a Chat Completions request. */
export function chatBody(
  params: Anthropic.MessageCreateParamsNonStreaming,
  options: Pick<ChatOptions, 'provider' | 'reasoningEffort'>,
  schema: Record<string, unknown> | undefined,
  strict: boolean,
): Record<string, unknown> {
  const system = typeof params.system === 'string' ? params.system : (params.system ?? []).map((b) => b.text).join('\n\n');
  const messages = [
    ...(system !== '' ? [{ role: 'system', content: system }] : []),
    ...params.messages.map((m) => ({
      role: m.role,
      content:
        typeof m.content === 'string'
          ? m.content
          : m.content.map((b) => (b.type === 'text' ? b.text : '')).join('\n\n'),
    })),
  ];
  const responseFormat =
    schema === undefined
      ? undefined
      : { type: 'json_schema', json_schema: { name: 'answer', strict, schema: strict ? strictSchema(schema) : schema } };
  if (options.provider === 'local') {
    return {
      model: params.model,
      messages,
      // A local model costs nothing per token, so the cap is only a guard
      // against a model that never stops: twice the answer's budget.
      max_tokens: params.max_tokens * 2,
      ...(responseFormat !== undefined ? { response_format: responseFormat } : {}),
    };
  }
  const effort = options.reasoningEffort ?? OPENAI_LEAST_EFFORT[params.model];
  return {
    model: params.model,
    messages,
    // The cap counts the model's thinking too, so a model that thinks gets room for it.
    max_completion_tokens: params.max_tokens + (effort === 'none' ? 0 : THINKING_ROOM_TOKENS),
    ...(effort !== undefined ? { reasoning_effort: effort } : {}),
    ...(responseFormat !== undefined ? { response_format: responseFormat } : {}),
  };
}

// ---------------------------------------------------------------------------
// Schemas and answers
// ---------------------------------------------------------------------------

type Json = Record<string, unknown>;

const isObject = (v: unknown): v is Json => typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * The schema in the form OpenAI's strict mode accepts: every property listed
 * as required, and each one the kit's schema leaves optional allowed to be
 * null instead. `answerText` removes those nulls again, so the kit reads the
 * answer exactly as it reads Claude's.
 */
export function strictSchema(schema: Json): Json {
  const out: Json = { ...schema };
  if (Array.isArray(schema['anyOf'])) out['anyOf'] = schema['anyOf'].map((s) => (isObject(s) ? strictSchema(s) : s));
  if (isObject(schema['items'])) out['items'] = strictSchema(schema['items']);
  if (isObject(schema['properties'])) {
    const required = new Set(Array.isArray(schema['required']) ? (schema['required'] as string[]) : []);
    const properties: Json = {};
    for (const [key, value] of Object.entries(schema['properties'])) {
      const inner = isObject(value) ? strictSchema(value) : value;
      properties[key] = required.has(key) ? inner : { anyOf: [inner, { type: 'null' }] };
    }
    out['properties'] = properties;
    out['required'] = Object.keys(properties);
    out['additionalProperties'] = false;
  }
  return out;
}

/** Drop the nulls `strictSchema` allowed in place of a property the kit's schema leaves out. */
export function dropAddedNulls(value: unknown, schema: unknown): unknown {
  if (!isObject(schema)) return value;
  if (Array.isArray(value)) {
    return isObject(schema['items']) ? value.map((v) => dropAddedNulls(v, schema['items'])) : value;
  }
  if (!isObject(value)) return value;
  if (Array.isArray(schema['anyOf'])) {
    const branch = schema['anyOf'].find(
      (s) => isObject(s) && isObject(s['properties']) && Object.keys(value).every((k) => k in (s['properties'] as Json)) && fitsConsts(value, s),
    );
    return branch === undefined ? value : dropAddedNulls(value, branch);
  }
  if (!isObject(schema['properties'])) return value;
  const properties = schema['properties'];
  const required = new Set(Array.isArray(schema['required']) ? (schema['required'] as string[]) : []);
  const out: Json = {};
  for (const [key, v] of Object.entries(value)) {
    if (v === null && !required.has(key)) continue;
    out[key] = dropAddedNulls(v, properties[key]);
  }
  return out;
}

/** True when every single-value enum in `branch` matches `value` (the routes' per-paper branches). */
function fitsConsts(value: Json, branch: Json): boolean {
  const properties = branch['properties'] as Json;
  return Object.entries(properties).every(([key, s]) => {
    if (!isObject(s) || !Array.isArray(s['enum']) || s['enum'].length !== 1) return true;
    return !(key in value) || value[key] === s['enum'][0];
  });
}

/**
 * The JSON text inside a model's answer. Local models sometimes wrap it in a
 * thinking block or a code fence, or add a sentence; this keeps the object.
 */
export function answerText(content: string, strictFrom?: Json): string {
  const text = content.replace(/<think>[\s\S]*?<\/think>/g, '');
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start === -1 || end <= start) throw new Error(`the model's answer held no JSON object: ${text.slice(0, 200)}`);
  const json = text.slice(start, end + 1);
  if (strictFrom === undefined) return json;
  return JSON.stringify(dropAddedNulls(JSON.parse(json), strictFrom));
}

// ---------------------------------------------------------------------------
// The local server, checked at startup
// ---------------------------------------------------------------------------

/**
 * Asks the local model server what it has. Unreachable: prints why, and the
 * handler stops `blocks run`, since every answer would fall to the canned
 * stand-in, or, when the canned stand-in was asked for (`canned`), lets it
 * answer without a model. Reached but without the model: a warning only,
 * because some servers (llama.cpp) list a model under another name and
 * answer anyway.
 */
export async function checkLocalServer(
  model: string,
  who: Who,
  canned = false,
  env: NodeJS.ProcessEnv = process.env,
  send: typeof fetch = fetch,
): Promise<'ok' | 'unreachable' | 'missing'> {
  const url = localModelUrl(env);
  const key = env['LOCAL_API_KEY'] ?? '';
  let listed: string[];
  try {
    const response = await send(`${url}/models`, {
      headers: key !== '' ? { authorization: `Bearer ${key}` } : {},
      signal: AbortSignal.timeout(5_000),
    });
    if (!response.ok) throw new Error(String(response.status));
    const data = (await response.json()) as { data?: { id?: unknown }[] };
    listed = (data.data ?? []).map((m) => m.id).filter((id): id is string => typeof id === 'string');
  } catch {
    if (canned) {
      console.warn(`${who.tag} No model server answered at ${url}. ${who.cannedVar}=1 is set, so the canned stand-in answers every call, by fixed rules.`);
      return 'unreachable';
    }
    console.error(
      [
        `${who.tag} Not starting: no model server answered at ${url}, and ${who.noun} needs one to think.`,
        '  Start Ollama (or your own model server), then run `blocks run` again. If your server is',
        '  at another address, set LOCAL_MODEL_URL in .env to that address, ending in /v1.',
      ].join('\n'),
    );
    return 'unreachable';
  }
  if (!listed.includes(model)) {
    console.warn(
      [
        `${who.tag} Your model server at ${url} does not list ${model}. If the server does not have it,`,
        '  every answer comes from the canned stand-in instead.',
        `  With Ollama, run \`ollama pull ${model}\`. Or set ${who.modelVar} in .env to a model the server has${
          listed.length > 0 ? ` (${listed.slice(0, 8).join(', ')})` : ''
        }, then restart \`blocks run\`.`,
      ].join('\n'),
    );
    return 'missing';
  }
  return 'ok';
}
