# Managed MSK cluster (AWS)
resource "aws_msk_cluster" "kafka" {
  cluster_name = "prod-msk"
  kafka_version = "2.8.1"
  number_of_broker_nodes = 3

  broker_node_group_info {
    instance_type = "kafka.m5.large"
    client_subnets = [
      aws_subnet.private_a.id,
      aws_subnet.private_b.id,
      aws_subnet.private_c.id,
    ]
    security_groups = [aws_security_group.msk.id]
    storage_info {
      ebs_storage_info {
        volume_size = 1000
      }
    }
  }

  encryption_info {
    encryption_in_transit {
      client_broker = "TLS"   # enforce TLS for clients
      in_cluster    = true
    }
  }

  configuration_info {
    # optional: reference custom Kafka config
    # arn = aws_msk_configuration.example.arn
    revision = 1
  }
}

# Security group for MSK
resource "aws_security_group" "msk" {
  name        = "msk-sg"
  vpc_id      = aws_vpc.main.id
  description = "MSK access"
  ingress {
    from_port   = 9094
    to_port     = 9094
    protocol    = "tcp"
    cidr_blocks = [aws_subnet.private_a.cidr_block] # tighten per-az
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ECS cluster & simple task definition for consumers (outline)
resource "aws_ecs_cluster" "workers" {
  name = "async-workers"
}

resource "aws_ecs_task_definition" "worker" {
  family                   = "worker"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "1024"
  memory                   = "2048"
  execution_role_arn       = aws_iam_role.ecs_task_exec.arn
  task_role_arn            = aws_iam_role.ecs_task.arn

  container_definitions = jsonencode([
    {
      name = "worker"
      image = "123456789012.dkr.ecr.us-west-2.amazonaws.com/worker:latest"
      essential = true
      environment = [
        { name = "KAFKA_BOOTSTRAP_SERVERS", value = aws_msk_cluster.kafka.bootstrap_brokers_tls }
      ]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group" = "/ecs/worker"
          "awslogs-region" = "us-west-2"
          "awslogs-stream-prefix" = "ecs"
        }
      }
    }
  ])
}

# ECS service (Fargate)
resource "aws_ecs_service" "worker_svc" {
  name            = "worker-svc"
  cluster         = aws_ecs_cluster.workers.id
  task_definition = aws_ecs_task_definition.worker.arn
  desired_count   = 2
  launch_type     = "FARGATE"
  network_configuration {
    subnets         = [aws_subnet.private_a.id, aws_subnet.private_b.id]
    security_groups = [aws_security_group.ecs_sg.id]
  }
}